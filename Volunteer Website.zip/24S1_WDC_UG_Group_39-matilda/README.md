# Template Repository for COMP SCI 2207/7207 Web & Database Computing (2023 Semester 1)

Contains environment files for WDC 2023. Copy this template for a general sandbox.

Auto commit/push/sync to Github is disabled by default in this template repository.
Enable the GitDoc extension to use this fucntionality (either in your VSCode settings, or in the Dev Container settings)

**THIS IS A SINGLE APPROACH WEBSITE: WE HAVE DONE ONE ORGANISATION WITH MUTILPLE BRANCHES.**

FINAL VERSION IS IN BRANCH CALLED 'matilda'
INSTALL THESE BEFORE USING IF NOT ALREADY INSTALLED:

npm install express session

npm install nodemailer

npm install --save node-cron

npm install axios

npm install bcrypt

npm install google-auth-library --save

